<?php



/*


This file will be used to Deal with categories, dates, links or Tag when they are browsed.




*/

?>