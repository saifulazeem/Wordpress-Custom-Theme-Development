<?php



/*


This file will be used to Display post when any of post is opend.




*/

?>