<?php



/*


This file will be used to Extend the features of Theme.
Also work as mini Plugin.





*/











?>