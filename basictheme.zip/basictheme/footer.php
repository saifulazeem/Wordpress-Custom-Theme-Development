<?php



/*


This file will be used to Display footer of webiste its a part of template file.




*/

?>



  <div class="container-fluid" id="footer">
    <br>
    <br>
    <p>© 2020 All copyrights Reserved <a href="#fileinfo.com">fileinfo</a></p>
</div>
</body>
</html>