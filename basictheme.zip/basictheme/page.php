<?php


/*


This file will be used to Display pages of Wordpress




*/

?>